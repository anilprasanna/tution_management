<footer class="footer bg-dark text-white text-center py-3 mt-3 mb-0">
    <div class="container">
        <p class="mb-0">Copyright &copy; 2025 Derana Tuition Class</p>
        <p class="mb-0">
            Follow us on:
            <a href="#" class="text-white mx-1">
                <i class="bi bi-facebook"></i>
            </a>
            <a href="#" class="text-white mx-1">
                <i class="bi bi-twitter"></i>
            </a>
            <a href="#" class="text-white mx-1">
                <i class="bi bi-instagram"></i>
            </a>
        </p>
    </div>
</footer>

<!-- Bootstrap JS Bundle -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>